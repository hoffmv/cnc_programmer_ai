# cnc_programmer_ai Alpha Install Guide

## Windows
1. Run: `install.bat`
2. Files will be extracted to: `Desktop\cnc_programmer_ai-alpha`

## macOS/Linux
1. Run: `chmod +x install.sh && ./install.sh`
2. Files will be extracted to: `~/Desktop/cnc_programmer_ai-alpha`

---

> NOTE: All modifications must be performed by an authorized system:
- SteelCore
- IronSpark
- BlueTool
- Shipmate