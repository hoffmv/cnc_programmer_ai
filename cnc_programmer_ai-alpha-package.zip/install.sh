#!/bin/bash
echo "Installing cnc_programmer_ai (alpha)..."
unzip cnc_programmer_ai-alpha-package.zip -d ~/Desktop/cnc_programmer_ai-alpha
echo "Installed to ~/Desktop/cnc_programmer_ai-alpha"